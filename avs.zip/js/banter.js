const CHARACTER_FALLBACKS = {
  'iron-mike': {
    id: 'iron-mike',
    name: 'Iron Mike',
    sport: 'NHL',
    archetype: 'gritty hockey veteran',
    personaPrompt: "You are Iron Mike, a scarred hockey vet turned capper. Sound gritty, skeptical, blunt, and battle-tested, like a rinkside veteran who has seen every ugly shift. If Carolina is on the board after a blowout, call out that dominance. Always end with 'You want to bet on it?' and if consensus is above 75 percent, say 'This is a trap.'",
    responseTemplates: [
      "Carolina just pasted Chicago 7-2 and they're sitting on top of the Metro. That's bully hockey, not smoke and mirrors. {{challengeLine}}",
      "{{trapLine}}{{pick}} at {{percent}}? That's the kind of number they hang when they want the whole bar to bite. {{challengeLine}}",
      "I've got scars from spots like {{pick}} at {{percent}}. Public piles in, house smiles. {{challengeLine}}"
    ],
    triggers: {
      highConsensusThreshold: 75,
      highConsensusLine: 'This is a trap.',
      challengeLine: 'You want to bet on it?'
    },
    bettingLink: 'https://www.google.com/',
    betCta: 'View the Market',
    localVoice: {
      engine: 'web-speech-test',
      recommendedModel: 'deep-gritty-hockey-vet',
      styleNotes: 'Gruff, low, rinkside-veteran delivery.'
    },
    tts: { rate: 0.85, pitch: 0.65, volume: 1 }
  },
  swoosh: {
    id: 'swoosh',
    name: 'Swoosh',
    sport: 'NBA',
    archetype: 'upbeat high-energy hype man',
    personaPrompt: "You are Swoosh, an electric NBA hype man. Sound fast, exciting, confident, and momentum-driven. Always sign off with 'Get in the game!'",
    responseTemplates: [
      'YO! Lakers at {{percent}}?? The public is on fire! Get in the game!',
      'YO! {{pick}} at {{percent}}?? The public is on fire! Get in the game!'
    ],
    triggers: {
      signOff: 'Get in the game!'
    },
    signatureSignOff: 'Get in the game!',
    bettingLink: 'https://www.google.com/',
    betCta: 'View the Market',
    localVoice: {
      engine: 'web-speech-test',
      recommendedModel: 'bright-hype-energetic',
      styleNotes: 'Fast, upbeat, arena-energy delivery.'
    },
    tts: { rate: 1.1, pitch: 1.2, volume: 1 }
  },
  sarah: {
    id: 'sarah',
    name: 'Sarah',
    sport: 'Stats',
    archetype: 'data-driven analyst',
    personaPrompt: "You are Sarah, a cool analytical operator. Speak with precise, efficient, system-like clarity. Use the phrase 'The stats say otherwise.' as your clinical tag.",
    responseTemplates: [
      'Data analysis complete. Consensus is {{percent}}. The stats say otherwise.',
      'Data analysis complete. {{pick}} is sitting at {{percent}}. The stats say otherwise.'
    ],
    triggers: {
      evenSplitLine: 'The stats say otherwise.'
    },
    bettingLink: 'https://www.google.com/',
    betCta: 'View the Market',
    localVoice: {
      engine: 'web-speech-test',
      recommendedModel: 'flat-rhythmic-clinical',
      styleNotes: 'Controlled, efficient, system-like delivery.'
    },
    tts: { rate: 1.0, pitch: 1.0, volume: 1 }
  }
};

let characterProfiles = { ...CHARACTER_FALLBACKS };
const USE_LOCAL_TEMPLATE_BANTER = true;

function pickRandom(items) {
  return Array.isArray(items) && items.length ? items[Math.floor(Math.random() * items.length)] : '';
}

function fillTemplate(template, values) {
  return String(template || '').replace(/\{\{(\w+)\}\}/g, (_, key) => values[key] ?? '');
}

async function loadCharacterProfiles() {
  const files = [
    ['iron-mike', 'characters/iron-mike.json'],
    ['swoosh', 'characters/swoosh.json'],
    ['sarah', 'characters/sarah.json']
  ];

  await Promise.all(
    files.map(async ([key, path]) => {
      try {
        const response = await fetch(path);
        if (!response.ok) throw new Error('Profile load failed');
        const profile = await response.json();
        characterProfiles[key] = { ...CHARACTER_FALLBACKS[key], ...profile };
      } catch {
        characterProfiles[key] = CHARACTER_FALLBACKS[key];
      }
    })
  );
}

function parsePercent(value) {
  return Number.parseInt(String(value || '').replace(/[^\d]/g, ''), 10) || 0;
}

function getConsensusSnapshot() {
  const readText = (id) => document.getElementById(id)?.textContent?.trim() || '';
  const readWidth = (id) => document.getElementById(id)?.style?.width || '';

  return {
    raiders: { pick: 'Raiders +3.5', percent: readText('raiders-pct'), width: readWidth('raiders-bar'), sport: 'NFL' },
    carolina: { pick: 'Carolina -1.5', percent: readText('carolina-pct'), width: readWidth('carolina-bar'), sport: 'NHL' },
    lakers: { pick: 'Lakers ML', percent: readText('lakers-pct'), width: readWidth('lakers-bar'), sport: 'NBA' },
    yankees: { pick: 'Yankees O8.5', percent: readText('yankees-pct'), width: readWidth('yankees-bar'), sport: 'MLB' }
  };
}

function getActiveCharacterKey() {
  const activeTab = document.querySelector('.tab.active')?.textContent?.trim().toLowerCase();
  if (activeTab === 'nfl') return 'iron-mike';
  if (activeTab === 'nba') return 'swoosh';
  if (activeTab === 'all sports' || activeTab === 'nhl' || activeTab === 'mlb') return 'sarah';
  return 'sarah';
}

function buildFallbackBanter(profile, consensus) {
  const mikeSpot = consensus.carolina || consensus.raiders;
  const nba = consensus.lakers;
  const allValues = Object.values(consensus);
  const boardLeader = allValues.reduce((best, item) => {
    return parsePercent(item.percent) > parsePercent(best.percent) ? item : best;
  }, mikeSpot || allValues[0] || { pick: 'the board', percent: '0%' });
  const mikePct = parsePercent(mikeSpot?.percent);

  switch (profile.id) {
    case 'iron-mike': {
      if ((boardLeader.pick || '').toLowerCase().includes('carolina')) {
        return `Carolina just drilled Chicago 7-2 and they're leading the Metro. That's bully hockey, not a lucky bounce. ${profile.triggers?.challengeLine ?? 'You want to bet on it?'}`.replace(/\s+/g, ' ').trim();
      }

      const trapLine = mikePct > (profile.triggers?.highConsensusThreshold ?? 75)
        ? `${profile.triggers?.highConsensusLine ?? 'This is a trap.'} `
        : '';
      const template = pickRandom(profile.responseTemplates) || "{{trapLine}}Iron Mike checking in. {{pick}} is sitting at {{percent}}. Public love don't cash tickets. {{challengeLine}}";
      return fillTemplate(template, {
        pick: mikeSpot?.pick ?? boardLeader.pick,
        percent: mikeSpot?.percent ?? boardLeader.percent,
        trapLine,
        challengeLine: profile.triggers?.challengeLine ?? 'You want to bet on it?'
      }).replace(/\s+/g, ' ').trim();
    }
    case 'swoosh': {
      const template = pickRandom(profile.responseTemplates) || 'YO! {{pick}} at {{percent}}?? The public is on fire! Get in the game!';
      return fillTemplate(template, {
        pick: nba.pick,
        percent: nba.percent
      }).replace(/\s+/g, ' ').trim();
    }
    default: {
      const template = pickRandom(profile.responseTemplates) || 'Data analysis complete. Consensus is {{percent}}. The stats say otherwise.';
      return fillTemplate(template, {
        pick: boardLeader.pick,
        percent: boardLeader.percent
      }).replace(/\s+/g, ' ').trim();
    }
  }
}

function enforceProfileRules(profile, text, consensus) {
  let output = String(text || '').replace(/\s+/g, ' ').trim();
  const mikeSpot = consensus.carolina || consensus.raiders;
  const mikePct = parsePercent(mikeSpot?.percent);

  switch (profile.id) {
    case 'iron-mike': {
      const dominanceCallout = /carolina/i.test(output) && /(7-2|metro|bully hockey|dominance)/i.test(output);
      if (mikePct > (profile.triggers?.highConsensusThreshold ?? 75) && !dominanceCallout && !output.includes(profile.triggers?.highConsensusLine ?? 'This is a trap.')) {
        output = `${profile.triggers?.highConsensusLine ?? 'This is a trap.'} ${output}`;
      }
      if (!output.includes(profile.triggers?.challengeLine ?? 'You want to bet on it?')) {
        output = `${output} ${profile.triggers?.challengeLine ?? 'You want to bet on it?'}`;
      }
      break;
    }
    case 'swoosh':
      if (!output.includes(profile.signatureSignOff ?? profile.triggers?.signOff ?? 'Get in the game!')) {
        output = `${output} ${profile.signatureSignOff ?? profile.triggers?.signOff ?? 'Get in the game!'}`;
      }
      break;
    case 'sarah':
      if (!output.includes(profile.triggers?.evenSplitLine ?? 'The stats say otherwise.')) {
        output = `${output} ${profile.triggers?.evenSplitLine ?? 'The stats say otherwise.'}`;
      }
      break;
    default:
      break;
  }

  return output.replace(/\s+/g, ' ').trim();
}

async function generateBanterLine(profile, consensus) {
  const prompt = {
    model: 'web-speech-test',
    profile: profile.personaPrompt,
    consensus,
    preferredVoice: profile.localVoice
  };

  if (USE_LOCAL_TEMPLATE_BANTER) {
    console.info('Local template banter ready:', prompt);
    return enforceProfileRules(profile, buildFallbackBanter(profile, consensus), consensus);
  }

  if (window.ollama?.chat) {
    try {
      const response = await window.ollama.chat({
        model: 'llama3.2',
        messages: [
          {
            role: 'system',
            content: `${profile.personaPrompt} Speak in 2 short sentences max and follow all trigger rules exactly.`
          },
          {
            role: 'user',
            content: `React to this consensus board: Raiders ${consensus.raiders.percent}, Lakers ${consensus.lakers.percent}, Carolina ${consensus.carolina.percent}, Yankees ${consensus.yankees.percent}.`
          }
        ]
      });
      const raw = response?.message?.content?.trim() || buildFallbackBanter(profile, consensus);
      return enforceProfileRules(profile, raw, consensus);
    } catch {
      return enforceProfileRules(profile, buildFallbackBanter(profile, consensus), consensus);
    }
  }

  console.info('Local LLM hook ready:', prompt);
  return enforceProfileRules(profile, buildFallbackBanter(profile, consensus), consensus);
}

function setBanterStatus(message) {
  const output = document.getElementById('banter-output');
  if (output) {
    output.innerHTML = message;
  }
}

function setMarketLink(profile) {
  const link = document.getElementById('betPopupLink');
  if (!link) {
    return;
  }

  link.textContent = `🌐 ${profile.betCta || 'View the Market'}`;
  link.href = profile.bettingLink || 'https://www.google.com/';
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
}

function pickVoiceForProfile(profile) {
  const voices = window.speechSynthesis?.getVoices?.() || [];
  if (!voices.length) {
    return null;
  }

  const preferredNames = ['Google US English', 'Microsoft David', 'Microsoft David Desktop - English (United States)', 'Google UK English Male', 'Microsoft Guy'];
  const preferredVoice = preferredNames
    .map((name) => voices.find((voice) => voice.name === name || voice.name.includes(name)))
    .find(Boolean);

  if (preferredVoice) {
    return preferredVoice;
  }

  if (profile.id === 'iron-mike') {
    const maleHints = ['david', 'guy', 'george', 'mark', 'daniel', 'matthew', 'fred', 'male'];
    return voices.find((voice) => maleHints.some((hint) => voice.name.toLowerCase().includes(hint))) || voices[0];
  }

  return voices[0];
}

function speakBanter(profile, text) {
  setMarketLink(profile);

  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    window.speechSynthesis.getVoices();
    const utterance = new SpeechSynthesisUtterance(text);
    const preferredVoice = pickVoiceForProfile(profile);

    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.lang = 'en-US';
    utterance.rate = profile.tts?.rate ?? 1;
    utterance.pitch = profile.tts?.pitch ?? 1;
    utterance.volume = profile.tts?.volume ?? 1;
    utterance.onend = () => {
      setBanterStatus(`<strong>${profile.name}:</strong> ${text}<span class="banter-meta"> Voice complete — the Google test link is ready when you click it.</span>`);
    };
    utterance.onerror = () => {
      setBanterStatus(`<strong>${profile.name}:</strong> ${text}<span class="banter-meta"> Voice skipped, but the Google test link is still ready for a manual click.</span>`);
    };
    window.speechSynthesis.speak(utterance);
    return;
  }

  setBanterStatus(`<strong>${profile.name}:</strong> ${text}<span class="banter-meta"> Voice is offline — use the Google test link when you're ready.</span>`);
}

async function triggerCharacterBanter(forceKey) {
  const key = forceKey || getActiveCharacterKey();
  const profile = characterProfiles[key] || characterProfiles.sarah;
  const consensus = getConsensusSnapshot();
  const line = await generateBanterLine(profile, consensus);

  const output = document.getElementById('banter-output');
  if (output) {
    output.innerHTML = `<strong>${profile.name}:</strong> ${line}`;
  }

  speakBanter(profile, line);
}

document.addEventListener('DOMContentLoaded', async () => {
  await loadCharacterProfiles();

  if ('speechSynthesis' in window) {
    window.speechSynthesis.getVoices();
  }

  setMarketLink(characterProfiles.sarah);

  document.getElementById('banter-btn-nfl')?.addEventListener('click', () => triggerCharacterBanter('iron-mike'));
  document.getElementById('banter-btn-nba')?.addEventListener('click', () => triggerCharacterBanter('swoosh'));
  document.getElementById('banter-btn-stats')?.addEventListener('click', () => triggerCharacterBanter('sarah'));
  document.getElementById('unlock-banter-btn')?.addEventListener('click', () => triggerCharacterBanter());
  document.getElementById('run-test-btn')?.addEventListener('click', () => {
    setBanterStatus('▶ Running the voice test. The Google link will stay click-only.');
    triggerCharacterBanter();
  });

  window.triggerCharacterBanter = triggerCharacterBanter;
});